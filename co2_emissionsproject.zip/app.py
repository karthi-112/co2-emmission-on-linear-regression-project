#!/usr/bin/env python
# coding: utf-8

# In[2]:


# Importing libraries-----------------------------------------------------------------------------------------
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from scipy import stats
from sklearn.ensemble import RandomForestRegressor
from sklearn.tree import DecisionTreeRegressor
import ydata_profiling as yp 
import streamlit as st
import pandas_profiling
from streamlit_pandas_profiling import st_profile_report
from pandas_profiling import ProfileReport
import pickle


# Creating Sidebar-------------------------------------------------------------------------------------------
with st.sidebar:
    st.markdown("# CO2 Emissions by Vehicle")
    user_input = st.selectbox('Please select',('Visulization','Model'))

# Load the vehicle dataset
df = pd.read_csv('co2_emissions.csv')


# Visulization-------------------------------------------------------------------------------------------------
if user_input == 'Visulization':
    

    # Remove unwanted warnings---------------------------------------------------------------------------------
    st.set_option('deprecation.showPyplotGlobalUse', False)

    # Showing Dataset------------------------------------------------------------------------------------------
    data = pd.read_csv("co2_emissions.csv" , na_values=['='])
    profile = ProfileReport(data)
    st.title=("Padas profiling in Streamlit")
    st.write(data)
    st_profile_report(profile)

    # Brands of Cars-------------------------------------------------------------------------------------------
    st.subheader('Brands of Cars')
    df_brand = df['make'].value_counts().reset_index().rename(columns={'index':'Index'})
    plt.figure(figsize=(20, 6))   
    fig1 = sns.barplot(data=df_brand, x="make", y="Index")
    plt.xticks(rotation=75)
    plt.title("All Car Companies and their Cars")
    plt.xlabel("Companies")
    plt.ylabel("Cars")
    plt.bar_label(fig1.containers[0], fontsize=7)
    st.pyplot()
    st.write(df_brand)

    # Top 25 Models of Cars------------------------------------------------------------------------------------
    st.subheader('Top 25 Models of Cars')
    df_model = df['model'].value_counts().reset_index().rename(columns={'index':'Index'})[:25]
    plt.figure(figsize=(20, 6))
    fig2 = sns.barplot(data=df_model[:25], x="model", y="Index")
    plt.xticks(rotation=75)
    plt.title("Top 25 Car Models")
    plt.xlabel("Models")
    plt.ylabel("Cars")
    plt.bar_label(fig2.containers[0])
    st.pyplot()
    st.write(df_model)

    # Vehicle Class--------------------------------------------------------------------------------------------
    st.subheader('vehicle_class')
    df_vehicle_class = df['vehicle_class'].value_counts().reset_index().rename(columns={'index':'Index'})
    plt.figure(figsize=(20, 5))
    fig3 = sns.barplot(data=df_vehicle_class, x="vehicle_class", y="Index")
    plt.xticks(rotation=75)
    plt.title("All Vehicle Class")
    plt.xlabel("Vehicle Class")
    plt.ylabel("Cars")
    plt.bar_label(fig3.containers[0])
    st.pyplot()
    st.write(df_vehicle_class)

    # Engine Sizes of Cars-------------------------------------------------------------------------------------
    st.subheader('Engine Sizes of Cars')
    df_engine_size = df['engine_size'].value_counts().reset_index().rename(columns={'index':'Index'})
    plt.figure(figsize=(20, 6))
    fig4 = sns.barplot(data=df_engine_size, x="engine_size", y="Index")
    plt.xticks(rotation=90)
    plt.title("All Engine Sizes")
    plt.xlabel("engine_size")
    plt.ylabel("Cars")
    plt.bar_label(fig4.containers[0])
    st.pyplot()
    st.write(df_engine_size)

    # Cylinders-----------------------------------------------------------------------------------------------
    st.subheader('cylinders')
    df_cylinders = df['cylinders'].value_counts().reset_index().rename(columns={'index':'Index'})
    plt.figure(figsize=(20, 6))
    fig5 = sns.barplot(data=df_cylinders, x="cylinders", y="Index")
    plt.xticks(rotation=90)
    plt.title("All cylinders")
    plt.xlabel("cylinders")
    plt.ylabel("Cars")
    plt.bar_label(fig5.containers[0])
    st.pyplot()
    st.write(df_cylinders)

    # Transmission of Cars------------------------------------------------------------------------------------
    transmission_mapping = { "A4": "Automatic", "A5": "Automatic", "A6": "Automatic", "A7": "Automatic", "A8": "Automatic", "A9": "Automatic", "A10": "Automatic", "AM5": "Automated Manual", "AM6": "Automated Manual", "AM7": "Automated Manual", "AM8": "Automated Manual", "AM9": "Automated Manual", "AS4": "Automatic with Select Shift", "AS5": "Automatic with Select Shift", "AS6": "Automatic with Select Shift", "AS7": "Automatic with Select Shift", "AS8": "Automatic with Select Shift", "AS9": "Automatic with Select Shift", "AS10": "Automatic with Select Shift", "AV": "Continuously Variable", "AV6": "Continuously Variable", "AV7": "Continuously Variable", "AV8": "Continuously Variable", "AV10": "Continuously Variable", "M5": "Manual", "M6": "Manual", "M7": "Manual"}
    df["transmission"] = df["transmission"].map(transmission_mapping)
    st.subheader('transmission')
    df_transmission = df['transmission'].value_counts().reset_index().rename(columns={'index': 'Index'})
    fig6 = plt.figure(figsize=(20, 5))
    sns.barplot(data=df_transmission, x="transmission", y="Index")
    plt.title("All Transmissions")
    plt.xlabel("transmission")
    plt.ylabel("Cars")
    plt.bar_label(plt.gca().containers[0])
    st.pyplot(fig6)
    st.write(df_transmission)

    # Fuel Type of Cars--------------------------------------------------------------------------------------
    st.subheader('fuel_type')
    df_fuel_type = df["fuel_type"].value_counts().reset_index().rename(columns={'index': 'Index'})
    fig7 = plt.figure(figsize=(20, 5))
    sns.barplot(data=df_fuel_type, x="fuel_type", y="Index")
    plt.title("All Fuel Types")
    plt.xlabel("Fuel Types")
    plt.ylabel("Cars")
    plt.bar_label(plt.gca().containers[0])
    st.pyplot(fig7)
    st.text("We have only one data on natural gas. So we cannot predict anything using only one data. That's why we have to drop this row.")
    st.write(df_fuel_type)

    # CO2 Emission variation with Brand----------------------------------------------------------------------
    st.header('Variation in CO2 emissions with different features')
    st.subheader('CO2 Emission with Brand ')
    df_co2_make = df.groupby(['make'])['co2_emissions'].mean().sort_values().reset_index()
    fig8 = plt.figure(figsize=(20, 5))
    sns.barplot(data=df_co2_make, x="make", y="co2_emissions")
    plt.xticks(rotation=90)
    plt.title("CO2 Emissions variation with Brand")
    plt.xlabel("Brands")
    plt.ylabel("co2_emissions")
    plt.bar_label(plt.gca().containers[0], fontsize=8, fmt='%.1f')
    st.pyplot(fig8)

    def plot_bar(data, x_label, y_label, title):
        plt.figure(figsize=(23, 5))
        sns.barplot(data=data, x=x_label, y=y_label)
        plt.xticks(rotation=90)
        plt.title(title)
        plt.xlabel(x_label)
        plt.ylabel(y_label)
        plt.bar_label(plt.gca().containers[0], fontsize=9)

    # CO2 Emissions variation with Vehicle Class-------------------------------------------------------------
    st.subheader('CO2 Emissions variation with Vehicle Class')
    df_co2_vehicle_class = df.groupby(['vehicle_class'])['co2_emissions'].mean().sort_values().reset_index()
    plot_bar(df_co2_vehicle_class, "vehicle_class", "co2_emissions", "CO2 Emissions variation with Vehicle Class")
    st.pyplot()

    # CO2 Emission variation with Transmission---------------------------------------------------------------
    st.subheader('CO2 Emission variation with Transmission')
    df_co2_transmission = df.groupby(['transmission'])['co2_emissions'].mean().sort_values().reset_index()
    plot_bar(df_co2_transmission, "transmission", "co2_emissions", "CO2 Emission variation with Transmission")
    st.pyplot()

    # CO2 Emissions variation with Fuel Type--------------------------------------------------------------
    st.subheader('CO2 Emissions variation with Fuel Type')
    df_co2_fuel_type = df.groupby(["fuel_type"])['co2_emissions'].mean().sort_values().reset_index()
    plot_bar(df_co2_fuel_type, "fuel_type", "co2_emissions", "CO2 Emissions variation with Fuel Type")
    st.pyplot()

    
 
    
else:
    Model = pickle.load(open('Decision_Tree_Regression_model.pkl','rb'))
    def pred(features):
        return Model.predict(features)
    
    # Create the Streamlit web app---------------------------------------------------------------------
    st.title='CO2 Emission Prediction'
    st.write('Enter the vehicle specifications to predict CO2 emissions.')
    
    # Input fields for user----------------------------------------------------------------------------
    
    Make=st.number_input("Enter Make",min_value=2, max_value=16, step=1)
    Model=st.number_input("Enter Model",min_value=2, max_value=16, step=1)
    Vehicle_Class = st.number_input("Enter Vehicle Class",min_value=2, max_value=16, step=1)
    Engine_Size_l= st.number_input("Enter Engine Size(L)", step=0.1, format="%.1f")
    Cylinders = st.number_input("Enter no of Cylinders", min_value=2, max_value=16, step=1)
    Fuel_Consumption_Comb=st.number_input("Enter Fuel_Consumption_Comb", step=0.1, format="%.1f")
    Fuel_Premium_gasoline=st.number_input("Enter Fuel_Premium gasoline",min_value=2, max_value=16, step=1)
    Fuel_Regular_gasoline=st.number_input("Enter Fuel_Regular gasoline",min_value=2, max_value=16, step=1)
    AM=st.number_input("Enter AM",min_value=2, max_value=16, step=1)
    AS= st.number_input("Enter AS",min_value=2, max_value=16, step=1)
    CVT=st.number_input("Enter CVT",min_value=2, max_value=16, step=1)
    M=st.number_input("Enter M",min_value=2, max_value=16, step=1) 
    Fuel_Consumption_City=st.number_input("Enter Fuel Consumption City",step=0.1, format="%.1f")
    Fuel_Consumption_Hwy=st.number_input("Enter Fuel Consumption Hwy",step=0.1, format="%.1f")
    Fuel_Ethanol=st.number_input("Enter Fuel_Ethanol",min_value=2, max_value=16, step=1)
    Fuel_Consumption_Comb=st.number_input("Enter Fuel Consumption Comb (mpg)",min_value=2, max_value=16, step=1)

    
    
    if st.button("Predict CO2 Emissions"):
        features = [[Make, Model, Vehicle_Class,Engine_Size_l,Cylinders,Fuel_Consumption_City,Fuel_Consumption_Hwy,
                     Fuel_Consumption_Comb,Fuel_Consumption_Comb,Fuel_Ethanol,Fuel_Premium_gasoline,Fuel_Regular_gasoline,AM,
                     AS,CVT,M]]
        prediction=predict(features)
        st.write("Estimated CO2 Emissions:{predicton[0]:.2} g/km")
        


# In[ ]:




