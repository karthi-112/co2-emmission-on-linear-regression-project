#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Importing libraries-----------------------------------------------------------------------------------------
import matplotlib.pyplot as plt
import ydata_profiling as yp 
import seaborn as sns
import pandas as pd
import numpy as np
from scipy import stats
from sklearn.ensemble import RandomForestRegressor
import streamlit as st
import pandas_profiling
from streamlit_pandas_profiling import st_profile_report
from pandas_profiling import ProfileReport
import pickle
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split


# Creating Sidebar-------------------------------------------------------------------------------------------
with st.sidebar:
    st.markdown("co2_emissions.csv")
    user_input = st.selectbox('Please select',('Model','Visulization'))
    

df = pd.read_csv('co2_emissions.csv')



# Visulization-------------------------------------------------------------------------------------------------
if user_input == 'Visulization':

    # Remove unwanted warnings---------------------------------------------------------------------------------
    st.set_option('deprecation.showPyplotGlobalUse', False)

    # Showing Dataset------------------------------------------------------------------------------------------
    data = pd.read_csv("co2_emissions.csv" , na_values=['='])
    profile = ProfileReport(data)
    st.title=("Padas profiling in Streamlit")
    st.write(data)
    st_profile_report(profile)


else:
    Model=pickle.load(open('Decision_Tree_Regression_model.pkl','rb'))
    
    def predict(features):
        return Model.predict(features)
    
    # Create the Streamlit web app---------------------------------------------------------------------
    st.title='CO2 Emission Prediction'
    st.write('Enter the vehicle specifications to predict CO2 emissions.')
    
    # Input fields for user----------------------------------------------------------------------------
    
    Engine_Size_l= st.number_input("Enter Engine Size(L)", step=0.1, format="%.1f")
    Cylinders = st.number_input("Enter no of Cylinders", min_value=2, max_value=16, step=1)
    Fuel_Consumption_Comb=st.number_input("Enter Fuel_Consumption_Comb", step=0.1, format="%.1f")
    
    
    if st.button("Predict CO2 Emissions"):
        features = [[Engine_Size_l,Cylinders,Fuel_Consumption_Comb]]
        prediction=predict(features)
        st.write("Estimated CO2 Emissions:{predicton[0]:.2} g/km")


# In[ ]:




